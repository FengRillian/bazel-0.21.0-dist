# desugar_jdk_libs

This project contains a small subset of OpenJDK libraries simplified for use
on older runtimes.

This is not an official Google product.
